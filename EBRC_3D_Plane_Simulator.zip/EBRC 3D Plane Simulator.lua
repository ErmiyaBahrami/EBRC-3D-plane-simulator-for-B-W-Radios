--[[
 EBRC 3D Plane Simulator for B&W radios (X9D+, QX7 and other 128x64 / 212x64)
 Creator: Ermiya Bahrami  -  ebrc.ir
 Copy to SD:/SCRIPTS/TOOLS/"EBRC 3D Plane Simulator.lua"  and the folder EBRC3D to SD:/SCRIPTS/TOOLS/EBRC3D/
 Use an EMPTY model: the sim reads your real sticks (ail ele rud thr).
]]
local fmt=string.format
local CFG="/SCRIPTS/TOOLS/EBRC3D.cfg"
local S={plane=2,wOn=0,wKmh=15,wDir=0,wGust=30,wTurb=20,wShear=1,wTherm=0,
trees=1,bldg=1,pyl=0,hoops=0,sock=1,grid=1,rway=1,detail=1,
sEng=1,sFx=1,sStall=1,sVario=0,sCall=1,sWind=0,
cam=0,zoom=10,start=0,assist=0,crash=1,torque=100,expo=30,rates=100,eRev=0,aReset=1,
pspd=100,grav=100,pwr=100,scr=0,gates=0,gsz=1,mdet=1}
local function saveCfg()
 pcall(function()
  local f=io.open(CFG,"w")
  if f then
   local t=""
   for k,v in pairs(S) do t=t..k.."="..v..";" end
   io.write(f,t)
   io.close(f)
  end
 end)
end
local function loadCfg()
 pcall(function()
  local f=io.open(CFG,"r")
  if f then
   local s=io.read(f,600)
   io.close(f)
   if s then for k,v in string.gmatch(s,"(%a+)=(%-?%d+)") do
    if S[k]~=nil then S[k]=tonumber(v) end end end
  end
 end)
end
local X={S=S,st={},inp={ail=0,ele=0,rud=0,thr=0},dir="/SCRIPTS/TOOLS/EBRC3D/",
 mode="menu",rst=true,flown=false,quit=false,save=saveCfg}
X.W=function()
 if S.scr==1 then return 212 elseif S.scr==2 then return 128 end
 return LCD_W or 212
end
local evmap={}
local function reg(act,...)
 for i=1,select("#",...) do local v=select(i,...) if v then evmap[v]=act end end
end
reg("next",EVT_PLUS_FIRST,EVT_PLUS_REPT,EVT_ROT_RIGHT,EVT_VIRTUAL_NEXT,EVT_VIRTUAL_NEXT_REPT,EVT_DOWN_BREAK)
reg("prev",EVT_MINUS_FIRST,EVT_MINUS_REPT,EVT_ROT_LEFT,EVT_VIRTUAL_PREV,EVT_VIRTUAL_PREV_REPT,EVT_UP_BREAK)
reg("enter",EVT_ENTER_BREAK,EVT_VIRTUAL_ENTER)
reg("exit",EVT_EXIT_BREAK,EVT_VIRTUAL_EXIT)
reg("menu",EVT_MENU_BREAK,EVT_VIRTUAL_MENU)
reg("page",EVT_PAGE_BREAK,EVT_VIRTUAL_PREV_PAGE,EVT_VIRTUAL_NEXT_PAGE)
local mod,cur,err,last=nil,nil,nil,0
local function sw(name)
 mod=nil
 collectgarbage()
 local f,e=loadScript(X.dir..name)
 if f then
  local ok,m=pcall(f,X)
  if ok then mod=m else err=tostring(m) end
 else err=tostring(e) end
 cur=name
end
local function init()
 math.randomseed(getTime())
 loadCfg()
 last=getTime()
end
local function run(event)
 local now=getTime()
 local dt=(now-last)*.01
 if dt<.005 then dt=.005 elseif dt>.1 then dt=.1 end
 last=now
 if X.mode~=cur then sw(X.mode) end
 if mod then
  mod.run(evmap[event],dt,now)
 else
  lcd.clear()
  lcd.drawText(0,0,"EBRC 3D load error:",SMLSIZE)
  lcd.drawText(0,12,string.sub(err or "?",1,40),SMLSIZE)
  lcd.drawText(0,22,string.sub(err or "?",41,80),SMLSIZE)
  lcd.drawText(0,40,"EXIT = quit",SMLSIZE)
  if evmap[event]=="exit" then X.quit=true end
 end
 if X.quit then saveCfg() return 1 end
 return 0
end
return {init=init,run=run}
