local X=...
local S,st=X.S,X.st
local sin,cos,floor=math.sin,math.cos,math.floor
local atan2=math.atan2 or math.atan
local PI=math.pi
local RAD=PI/180
local fmt=string.format
local RT=RIGHT or 0
local SM=SMLSIZE or 0
local function clamp(v,a,b) if v<a then return a elseif v>b then return b end return v end
local PLS={{"Trainer","Easy","0.7",150,120},{"Sport F3A","Pattern","1.2",420,220},
{"XA 3D 30cc","3D","2.1",600,360},{"XA Xtreme50","Extreme","2.2",720,420},
{"Foam Hover","Indoor 3D","2.1",420,300},{"Warbird","Scale","0.85",300,160}}
local TICK="   EBRC 3D Plane Simulator for B&W radios  |  Creator: Ermiya Bahrami  |  Website: ebrc.ir  |  Telegram ID: @AUGUGA  |  Channel ID: @RollingHarrier  |  Email: ermiyabahrami@gmail.com  |   "
local function CH(l,k,...) return {l=l,k=k,ch={...}} end
local function NU(l,k,mn,mx,sp,u) return {l=l,k=k,mn=mn,mx=mx,sp=sp or 1,u=u or ""} end
local MENUS={}
local mcur,msel,mtop,medit="main",1,1,false
local mstack={}
local helpPage=1
local aboutPage=1
local inHelp,inAbout=false,false
local function openMenu(n)
 mstack[#mstack+1]={mcur,msel,mtop}
 mcur,msel,mtop,medit=n,1,1,false
end
local function backMenu()
 local n=#mstack
 local t=mstack[n]
 if t then mstack[n]=nil mcur,msel,mtop=t[1],t[2],t[3] medit=false return true end
 return false
end
local function toMain()
 local t=mstack[1]
 if t then mcur,msel,mtop=t[1],t[2],t[3] else mcur,msel,mtop="main",1,1 end
 mstack={}
 medit=false
end
local function itemVal(it)
 if it.pi~=nil then return (it.pi==S.plane) and "*" or nil end
 if it.sub then return ">" end
 if it.ch then return it.ch[S[it.k]+1] end
 if it.mn then return S[it.k]..it.u end
 return nil
end
local function adjust(it,d)
 local v=S[it.k]
 if it.ch then
  v=v+d
  if v<0 then v=#it.ch-1 elseif v>#it.ch-1 then v=0 end
 else v=clamp(v+d*it.sp,it.mn,it.mx) end
 S[it.k]=v
end
local function ppreview(i)
 local p=PLS[i]
 local x=X.W()-58
 lcd.drawText(x,12,p[2],SM)
 lcd.drawText(x,22,"T/W "..p[3],SM)
 lcd.drawText(x,32,"Roll "..p[4],SM)
 lcd.drawText(x,42,"Pitch "..p[5],SM)
end
local function wpreview()
 local W=X.W()
 local cx,cy,r=W-31,26,13
 if S.wOn==0 then lcd.drawText(cx-18,28,"WIND OFF",SM) return end
 local px,py=cx+r,cy
 for i=1,16 do
  local a=i*PI/8
  local qx,qy=cx+r*cos(a),cy+r*sin(a)
  lcd.drawLine(floor(px),floor(py),floor(qx),floor(qy),SOLID,FORCE)
  px,py=qx,qy
 end
 lcd.drawText(cx-2,cy-r+2,"N",SM)
 local a=S.wDir*RAD
 local tx,ty=cx+sin(a)*r,cy-cos(a)*r
 lcd.drawLine(floor(tx),floor(ty),cx,cy,SOLID,FORCE)
 local ang=atan2(cy-ty,cx-tx)
 lcd.drawLine(cx,cy,floor(cx-5*cos(ang-.5)),floor(cy-5*sin(ang-.5)),SOLID,FORCE)
 lcd.drawLine(cx,cy,floor(cx-5*cos(ang+.5)),floor(cy-5*sin(ang+.5)),SOLID,FORCE)
 lcd.drawText(W-58,41,fmt("%ddeg",S.wDir),SM)
 lcd.drawText(W-58,48,fmt("%dkm/h",S.wKmh),SM)
end
local function startFly()
 X.save()
 X.mode="fly"
 X.flown=true
end
MENUS.main={t="EBRC 3D Plane Sim",items={
{l="Fly",act=startFly},
{l="Plane",sub="plane"},
{l="Wind",sub="wind"},
{l="Scenery",sub="scen"},
{l="Physics",sub="phys"},
{l="Sound",sub="snd"},
{l="Options",sub="opt"},
{l="Maneuver help",act=function() inHelp=true helpPage=1 end},
{l="About / Contact",act=function() inAbout=true aboutPage=1 end},
{l="Reset plane",act=function() X.rst=true st.score=0 st.gp=0 st.lap=0 st.best=nil startFly() end},
{l="Exit",act=function() X.quit=true end},
}}
MENUS.plane={t="SELECT PLANE",items={},pv=ppreview}
for i=1,#PLS do
 MENUS.plane.items[i]={l=PLS[i][1],pi=i-1,act=function() S.plane=i-1 X.rst=true st.score=0 st.gp=0 st.lap=0 st.best=nil end}
end
MENUS.wind={t="WIND",pv=wpreview,items={
CH("Wind","wOn","Off","On"),
NU("Speed","wKmh",0,70,1,"km/h"),
NU("From","wDir",0,350,10,"d"),
NU("Gusts","wGust",0,100,10,"%"),
NU("Turb","wTurb",0,100,10,"%"),
CH("Shear","wShear","Off","On"),
CH("Thermal","wTherm","Off","On"),
}}
MENUS.phys={t="PHYSICS",items={
NU("Sim speed","pspd",25,300,25,"%"),
NU("Gravity","grav",50,150,10,"%"),
NU("Engine power","pwr",50,150,10,"%"),
NU("Torque","torque",0,150,10,"%"),
CH("Level assist","assist","Off","On"),
CH("Crash","crash","Off","On"),
}}
MENUS.scen={t="SCENERY",items={
CH("Trees","trees","Off","On"),CH("Buildings","bldg","Off","On"),
CH("Pylons","pyl","Off","On"),CH("Hoops","hoops","Off","On"),
CH("Windsock","sock","Off","On"),CH("Ground grid","grid","Off","On"),
CH("Runway","rway","Off","On"),CH("Detail","detail","Low","Med","High"),
CH("Gates","gates","Off","On"),CH("Gate size","gsz","Small","Med","Large"),
{l="Reset gate count",act=function() st.gp=0 st.lap=0 st.best=nil st.gn=1 st.lt=nil st.arm=false end},
}}
MENUS.snd={t="SOUND",items={
CH("Engine","sEng","Off","On"),CH("Effects","sFx","Off","On"),
CH("Stall alarm","sStall","Off","On"),CH("Vario","sVario","Off","On"),
CH("Callouts","sCall","Off","On"),CH("Wind noise","sWind","Off","On"),
}}
MENUS.opt={t="OPTIONS",items={
CH("Screen","scr","Auto","212x64","128x64"),
CH("Camera","cam","Pilot","Chase","FPV"),
NU("Zoom","zoom",5,30,1,""),
CH("Start","start","Runway","Air","Hover"),
CH("Maneuver detector","mdet","Off","On"),
NU("Expo","expo",0,80,10,"%"),
NU("Rates","rates",50,150,10,"%"),
CH("Elev reverse","eRev","Off","On"),
CH("Auto reset","aReset","Off","On"),
}}
local HELP={
{"CONTROLS","Sticks = AETR (real)","PAGE  = camera","+/-   = zoom","SH/ENTER = reset plane","MENU=main menu EXIT=back"},
{"HOVER","Nose up 90 deg","3D planes: 45-50% thr","Small elev/rud inputs","Aileron fights torque","Needs T/W > 1.8"},
{"TORQUE ROLL","Enter a hover first","Hold nose up w/ thr","Aileron = spin round","the thrust axis","Keep elev/rud small"},
{"RIFLE ROLL","Full aileron held","High throttle (60%+)","Add elev/rudder to","hold altitude or to","change direction"},
{"TUMBLE","Slow, nose high","Cut throttle","Full up elevator","Best: XA Xtreme50","Centre sticks to stop"},
{"HARRIER/KNIFE","Harrier: 40deg alpha","slow, throttle ~50%","Knife edge: bank 90","hold with rudder +","some elevator"},
{"SPIN/BLENDER","Flat spin: level, slow","full rudder + power","Blender: tumble plus","roll plus rudder","all at once"},
{"WIND","From = where wind","comes from, 0 = head","wind on runway (km/h)","Gust/Turb = bumps","Shear = calm low down"},
{"PHYSICS","Sim speed 25-300%","slow-mo to practise","Gravity / engine power","scale the flight model","Torque = prop torque"},
{"GATES","Scenery > Gates On","Fly gates in order","G=next L=laps P=passes","Lap time on the HUD","Size: Scenery menu"},
{"SCORING","Maneuvers score pts","Hoop +10, lap +50","Crash resets plane","Detail Low = faster","on a slow radio"},
}
local function drawTitle(W,txt,cnt)
 lcd.drawFilledRectangle(0,0,W,9)
 lcd.drawText(2,1,txt,SM+INVERS)
 lcd.drawText(W-26,1,cnt,SM+INVERS)
end
local function drawMenu(dt)
 local W=X.W()
 lcd.clear()
 local M=MENUS[mcur]
 local ttl=M.t
 local cnt=fmt("%d/%d",msel,#M.items)
 if mcur=="main" then
  ttl=(W>=200) and "EBRC 3D Plane Sim - Ermiya Bahrami" or "EBRC - Ermiya Bahrami"
  cnt=""
 elseif W>=200 then ttl=M.t.." - Ermiya Bahrami" end
 drawTitle(W,ttl,cnt)
 local w=M.pv and (W-64) or (W-1)
 local rows=5
 if msel<mtop then mtop=msel elseif msel>mtop+rows-1 then mtop=msel-rows+1 end
 for i=0,rows-1 do
  local it=M.items[mtop+i]
  if not it then break end
  local y=11+i*9
  local sel=(mtop+i==msel)
  local fl=SM
  if sel then lcd.drawFilledRectangle(0,y-1,w,9) fl=SM+INVERS end
  lcd.drawText(2,y,it.l,fl)
  local v=itemVal(it)
  if v then
   local vf=fl
   if sel and medit then vf=fl+BLINK end
   lcd.drawText(w-2,y,v,vf+RT)
  end
 end
 if M.pv then
  if mcur=="plane" then M.pv(msel) else M.pv() end
 end
 lcd.drawLine(0,55,W-1,55,SOLID,FORCE)
 local n=floor(W/5)+1
 local p=floor(getTime()/20)%#TICK
 lcd.drawText(0,57,string.sub(TICK..TICK,p+1,p+n),SM)
end
local function menuInput(act)
 local M=MENUS[mcur]
 local it=M.items[msel]
 if act=="menu" then
  if mcur~="main" then toMain() elseif X.flown then startFly() end
  return
 end
 if medit then
  if act=="next" then adjust(it,1) elseif act=="prev" then adjust(it,-1)
  elseif act=="enter" or act=="exit" then medit=false end
  return
 end
 if act=="next" then msel=msel%#M.items+1
 elseif act=="prev" then msel=(msel-2)%#M.items+1
 elseif act=="enter" then
  if it.sub then openMenu(it.sub)
  elseif it.act then it.act()
  elseif it.ch then adjust(it,1)
  elseif it.mn then medit=true end
 elseif act=="exit" then
  if not backMenu() then
   if X.flown then startFly() else X.quit=true end
  end
 end
end
local function helpFrame(act)
 local W=X.W()
 lcd.clear()
 local H=HELP[helpPage]
 drawTitle(W,H[1],fmt("%d/%d",helpPage,#HELP))
 for i=2,#H do lcd.drawText(2,3+(i-1)*9,H[i],SM) end
 if act=="next" or act=="enter" then helpPage=helpPage%#HELP+1
 elseif act=="prev" then helpPage=(helpPage-2)%#HELP+1
 elseif act=="exit" or act=="menu" then inHelp=false end
end
local ABOUT={
{"EBRC 3D Plane Simulator","for B&W radios","Creator:","Ermiya Bahrami","Website: ebrc.ir"},
{"Telegram ID: @AUGUGA","Channel ID:","@RollingHarrier","Email:","ermiyabahrami@gmail.com"},
}
local function aboutFrame(act)
 local W=X.W()
 lcd.clear()
 drawTitle(W,"ABOUT",fmt("%d/%d",aboutPage,#ABOUT))
 local L=ABOUT[aboutPage]
 for i=1,#L do lcd.drawText(2,3+i*8,L[i],SM) end
 if act=="next" or act=="prev" or act=="enter" then aboutPage=aboutPage%#ABOUT+1
 elseif act=="exit" or act=="menu" then inAbout=false end
end
return {run=function(act,dt)
 if inAbout then aboutFrame(act) elseif inHelp then helpFrame(act) else menuInput(act) drawMenu(dt) end
end}
