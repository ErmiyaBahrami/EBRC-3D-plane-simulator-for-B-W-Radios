local RAD=math.pi/180
local cos,sin=math.cos,math.sin
local PL = {
{n="Trainer",   d="Easy",     len=1.1,sp=1.6,ch=.24,ts=.55,fh=.20,wz=.10, sw=0,  tp=1,  fw=1,
tw=.7, kL=.12,cd=.06, ca=4.5,sa=16,rl=150,pt=120,yw=80, vr=14,wa=6, sb=2.2,cg=0,  tq=.2,ta=.15,vm=28,cv=5.5},
{n="Sport F3A", d="Pattern",  len=1.4,sp=1.6,ch=.26,ts=.50,fh=.22,wz=0,   sw=.03,tp=.85,fw=1,
tw=1.2,kL=.16,cd=.035,ca=5,  sa=15,rl=420,pt=220,yw=120,vr=15,wa=9, sb=2.8,cg=0,  tq=.5,ta=.09,vm=45,cv=5},
{n="XA 3D 30cc",d="3D",       len=1.7,sp=1.9,ch=.38,ts=.75,fh=.34,wz=0,   sw=.05,tp=.8, fw=1.1,
tw=2.1,kL=.18,cd=.08, ca=5,  sa=18,rl=600,pt=360,yw=250,vr=13,wa=14,sb=1.4,cg=.35,tq=1.4,ta=.07,vm=40,cv=5},
{n="XA Xtreme50",d="Extreme", len=2.0,sp=2.2,ch=.45,ts=.90,fh=.40,wz=0,   sw=.06,tp=.75,fw=1.2,
tw=2.2,kL=.17,cd=.10, ca=5,  sa=20,rl=720,pt=420,yw=300,vr=12,wa=16,sb=1.0,cg=.8, tq=2.2,ta=.06,vm=45,cv=5},
{n="Foam Hover",d="Indoor 3D",len=.9, sp=1.0,ch=.30,ts=.50,fh=.25,wz=0,   sw=0,  tp=1,  fw=.6,
tw=2.1,kL=.35,cd=.15, ca=4,  sa=22,rl=420,pt=300,yw=240,vr=8, wa=9, sb=1.2,cg=.5, tq=1.2,ta=.06,vm=22,cv=8},
{n="Warbird",   d="Scale",    len=1.6,sp=1.8,ch=.30,ts=.55,fh=.26,wz=-.05,sw=.10,tp=.6, fw=1.3,
tw=.85,kL=.12,cd=.04, ca=4.6,sa=14,rl=300,pt=160,yw=90, vr=18,wa=7, sb=3.2,cg=0,  tq=.8,ta=.13,vm=50,cv=4.5},
}
local function buildMesh(p)
local L,sp,c,fw = p.len,p.sp,p.ch,p.fw
local vx,vy,vz,ea,eb = {},{},{},{},{}
local n = 0
local function V(x,y,z) n=n+1 vx[n]=x vy[n]=y vz[n]=z return n end
local function E(a,b) ea[#ea+1]=a eb[#eb+1]=b end
local stt = {{.5,.012,.012},{.3,.075,.085},{0,.085,.1},{-.5,.01,.025}}
local ring = {}
for i=1,4 do
local s = stt[i]
local x,w,h = s[1]*L, s[2]*L*fw, s[3]*L*fw
ring[i] = {V(x,w,h),V(x,-w,h),V(x,-w,-h),V(x,w,-h)}
for k=1,4 do E(ring[i][k],ring[i][k%4+1]) end
if i>1 then for k=1,4 do E(ring[i-1][k],ring[i][k]) end end
end
local cx,wz,b = .08*L, p.wz, sp/2
local sw = p.sw*sp
local tipc = c*p.tp
local lr,tr = V(cx+c/2,0,wz), V(cx-c/2,0,wz)
local ltl,ltt = V(cx+c/2-sw,b,wz), V(cx+c/2-sw-tipc,b,wz)
local rtl,rtt = V(cx+c/2-sw,-b,wz), V(cx+c/2-sw-tipc,-b,wz)
E(lr,tr) E(lr,ltl) E(ltl,ltt) E(ltt,tr) E(lr,rtl) E(rtl,rtt) E(rtt,tr)
local function hx(f) return cx+c/2-sw*f-(c+(tipc-c)*f)*.7 end
local function tx(f) return cx+c/2-sw*f-(c+(tipc-c)*f) end
for sd=-1,1,2 do
local a0,a1,a2 = V(hx(.45),b*.45*sd,wz),V(hx(1),b*sd,wz),V(tx(.45),b*.45*sd,wz)
E(a0,a1) E(a0,a2)
end
local xt,sc,tb = -.44*L, c*.55, p.ts/2
local t1,t2,t3,t4 = V(xt+sc/2,tb,0),V(xt-sc/2,tb,0),V(xt-sc/2,-tb,0),V(xt+sc/2,-tb,0)
E(t1,t2) E(t2,t3) E(t3,t4) E(t4,t1)
local h1,h2 = V(xt-sc*.1,tb,0),V(xt-sc*.1,-tb,0)
E(h1,h2)
local f1,f2 = V(xt+sc/2,0,0),V(xt-sc/2,0,0)
local f3,f4 = V(xt-sc/2-.03*L,0,p.fh),V(xt+sc/4,0,p.fh)
E(f1,f4) E(f4,f3) E(f3,f2)
return {vx=vx,vy=vy,vz=vz,ea=ea,eb=eb,n=n,pr=.13*L,nx=.5*L+.015}
end
return function(i)
local s=PL[i+1] or PL[1]
local p={}
for k,v in pairs(s) do p[k]=v end
p.sa=p.sa*RAD p.rl=p.rl*RAD p.pt=p.pt*RAD p.yw=p.yw*RAD
return p,buildMesh(p)
end
