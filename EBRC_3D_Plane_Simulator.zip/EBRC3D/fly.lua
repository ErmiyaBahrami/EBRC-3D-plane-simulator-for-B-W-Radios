local X=...
local S,st,inp=X.S,X.st,X.inp
local sin,cos,sqrt,abs,floor,min,max,asin=math.sin,math.cos,math.sqrt,math.abs,math.floor,math.min,math.max,math.asin
local atan2=math.atan2 or math.atan
local PI=math.pi
local RAD=PI/180
local fmt=string.format
local rnd=math.random
local G,ZG=9.81,0.15
local TU=1
local RT=RIGHT or 0
local PN=PLAY_NOW or 0
local PB=PLAY_BACKGROUND or 0
local SM=SMLSIZE or 0
local P,mesh
local W=212
local function clamp(v,a,b) if v<a then return a elseif v>b then return b end return v end
local function sgn(v) if v<0 then return -1 end return 1 end
local function loadPlane(i)
local f=loadScript(X.dir.."planes")
P,mesh=f()(i)
f=nil
collectgarbage()
end
local TREES = {{-25,10},{-30,40},{28,25},{35,-10},{-40,-20},{45,45},{-55,5},{55,-30},
{20,70},{-20,75},{60,10},{-60,50},{0,95},{75,80},{-85,-40},{90,-5}}
local BLDG  = {{-32,-18,12,8,5},{38,52,9,9,6}}
local PYL   = {{-14,25},{14,25},{-14,65},{14,65}}
local HOOP  = {{0,20,5,0,3},{0,60,8,0,3},{-25,85,10,270,3},{-55,60,9,180,3},{-55,20,6,180,3},{-30,-5,5,90,3}}
local GATE={{0,20,5,0},{0,60,6,0},{30,85,7,90},{65,65,6,180},{65,25,5,180},{35,0,5,270}}
local GW={4,6,9}
local SOCK  = {14,-30}
local THERM = {-40,30,14}
local PX,PY,PZ = 8,-42,1.7        -- pilot position
local solids = {}
local function buildSolids()
solids = {}
if S.trees==1 then
for i=1,({6,10,16})[S.detail+1] do
local t=TREES[i] solids[#solids+1]={1,t[1],t[2],1.0,6+(i*7)%5}
end
end
if S.bldg==1 then
for i=1,#BLDG do local b=BLDG[i]
solids[#solids+1]={2,b[1],b[2],b[3]/2+.3,b[4]/2+.3,b[5]} end
end
if S.pyl==1 then
for i=1,#PYL do solids[#solids+1]={1,PYL[i][1],PYL[i][2],.4,8} end
end
end
local ph1,ph2,ph3,ph4 = 0,0,0,0
local function windAt(x,y,z,t)
local wx,wy,wz = 0,0,0
if S.wOn==1 then
local sp = S.wKmh/3.6
local m = 1
if S.wShear==1 then m = clamp(.35+z*.05,.35,1.15) end
local g = 0
if S.wGust>0 then
g = max(0,sin(t*.55+ph1)*sin(t*.23+ph2))*S.wGust*.01*max(sp,3)
end
local w = (sp+g)*m
local th = S.wDir*RAD
wx,wy = -sin(th)*w, -cos(th)*w
local T = S.wTurb*.03
if T>0 then
wx = wx + T*(sin(t*3.1+ph3+y*.1)+.5*sin(t*7.3+ph4))
wy = wy + T*(sin(t*2.7+ph4+x*.1)+.5*sin(t*6.1+ph3))
wz = wz + T*.6*(sin(t*3.9+ph1+x*.07)+.5*sin(t*8.3+ph2))
end
if S.wTherm==1 then
local dx,dy = x-THERM[1],y-THERM[2]
local d2 = (dx*dx+dy*dy)/(THERM[3]*THERM[3])
if d2<1 then wz = wz + 4*(1-d2) end
end
end
return wx,wy,wz
end
local pending, lastSnd, sndTog = nil, 0, 0
local DT = .02
local function pend(n)
local pr = {crash=5,hoop=4,man=3,stall=2,touch=1}
if not pending or pr[n]>pr[pending] then pending=n end
end
local function resetPlane()
loadPlane(S.plane)
buildSolids()
local s = st
s.vx,s.vy,s.vz,s.p,s.q,s.r = 0,0,0,0,0,0
s.x,s.y,s.z = 0,-38,ZG
s.fx,s.fy,s.fz,s.lx,s.ly,s.lz,s.ux,s.uy,s.uz = 0,1,0,-1,0,0,0,0,1
s.eng = 0
if S.start==1 then
s.y,s.z,s.vy,s.eng = -25,14,12,.5
elseif S.start==2 then
s.y,s.z,s.eng = -12,6,1/P.tw
s.fx,s.fy,s.fz,s.ux,s.uy,s.uz = 0,0,1,0,-1,0
end
s.crashed,s.ct,s.gnd = false,0,(S.start==0)
s.t,s.ph,s.V,s.al,s.vf = 0,0,0,0,0
s.ra,s.la,s.ya = 0,0,0
s.tm,s.mk,s.cool = {},{},{}
s.manName,s.manT = "",0
s.wx,s.wy,s.wz = 0,0,0
s.hsd,s.gsd = nil,nil
st.gn,st.arm,st.lt = 1,false,nil
s.deb = {}
st.nextH = 1
ph1,ph2,ph3,ph4 = rnd()*6.28,rnd()*6.28,rnd()*6.28,rnd()*6.28
end
local function doCrash(why)
local s = st
if s.crashed then return end
s.crashed,s.ct,s.why = true,0,why
s.p,s.q,s.r = 0,0,0
s.deb = {}
for i=1,8 do s.deb[i] = {rnd()*2-1,rnd()*2-1,rnd()*2} end
pend("crash")
end
local function announce(name,pts)
local s = st
if s.cool[name] and s.t-s.cool[name]<3 then return end
s.cool[name] = s.t
s.manName,s.manT = name,2.5
st.score = st.score+pts
pend("man")
end
local function hold(k,cond,t,name,pts)
local s = st
if cond then
s.tm[k] = (s.tm[k] or 0)+DT
if s.tm[k]>t and not s.mk[k] then s.mk[k]=true announce(name,pts) end
else s.tm[k]=0 s.mk[k]=false end
end
local function detect(dt)
local s = st
if s.crashed then return end
DT = dt
if s.gnd then s.ra,s.la,s.ya = 0,0,0 s.tm,s.mk = {},{} return end
local V,fz,lz,uz,z = s.V,s.fz,s.lz,s.uz,s.z
local aa = abs(s.al)
local hov = fz>.88 and V<4 and z>1.2
local rrc = abs(inp.ail)>.85 and inp.thr>.6 and abs(s.p)>3 and V>4 and z>1 and not hov and (abs(inp.ele)>.12 or abs(inp.rud)>.12)
if abs(s.p)>1.2 then s.ra = s.ra+s.p*dt else s.ra = 0 end
if abs(s.ra)>5.6 then
if hov then announce("TORQUE ROLL",30)
elseif rrc then announce("RIFLE ROLL",30)
else announce("ROLL",5) end
s.ra = 0
end
if abs(s.q)>1 then s.la = s.la+s.q*dt else s.la = 0 end
if abs(s.la)>5.3 then
if abs(s.q)>5 and V<12 then announce("TUMBLE",35) else announce("LOOP",5) end
s.la = 0
end
if abs(s.r)>1.5 then s.ya = s.ya+s.r*dt else s.ya = 0 end
if abs(s.ya)>5.3 then
if abs(uz)>.75 and abs(fz)<.5 then announce("FLAT SPIN",25) end
s.ya = 0
end
hold("hov",hov,1,"HOVER",20)
hold("har",aa>.5 and aa<1.4 and V>5 and abs(s.vz)<3 and z>2,1,"HARRIER",20)
hold("ke",V>8 and abs(lz)>.85 and abs(fz)<.35,.8,"KNIFE EDGE",15)
hold("inv",uz<-.8 and V>8 and abs(fz)<.4,1.2,"INVERTED",10)
hold("ts",s.vf<-3 and V>3,.5,"TAIL SLIDE",15)
hold("low",z<3 and V>14,.6,"LOW PASS",5)
hold("bl",abs(s.p)>3 and abs(s.q)>3 and abs(s.r)>3,.6,"BLENDER",40)
end
local function rot2(ax,ay,az,bx,by,bz,th)
local c,n = cos(th),sin(th)
return ax*c+bx*n, ay*c+by*n, az*c+bz*n, bx*c-ax*n, by*c-ay*n, bz*c-az*n
end
local function stepPhys(dt)
local s = st
local thr,ail,ele,rud = inp.thr,inp.ail,inp.ele,inp.rud
s.t = s.t+dt
s.eng = s.eng+(thr-s.eng)*min(1,dt*7)
local eng = s.eng
local wx,wy,wz = windAt(s.x,s.y,s.z,s.t)
s.wx,s.wy,s.wz = wx,wy,wz
local fx,fy,fz,lx,ly,lz,ux,uy,uz = s.fx,s.fy,s.fz,s.lx,s.ly,s.lz,s.ux,s.uy,s.uz
local rx,ry,rz = s.vx-wx,s.vy-wy,s.vz-wz
local vf = rx*fx+ry*fy+rz*fz
local vl = rx*lx+ry*ly+rz*lz
local vu = rx*ux+ry*uy+rz*uz
local V = sqrt(rx*rx+ry*ry+rz*rz)
local al = atan2(-vu,vf)
local aa = abs(al)
local sinA = sin(al)
local sinB = 0
if V>.1 then sinB = vl/V end
s.V,s.al,s.vf = V,al,vf
local cl
if aa<=P.sa then cl = P.ca*al
else
local t = min(1,(aa-P.sa)/.25)
cl = P.ca*P.sa*sgn(al)*(1-t)+.9*sin(2*al)*t
end
local cdv = P.cd+.1*cl*cl+(aa>P.sa and 1.1 or .25)*sinA*sinA+.8*sinB*sinB
local qk = P.kL*V*V
local ax,ay,az = 0,0,-G*S.grav*.01
if V>.5 then
local hx,hy,hz = rx/V,ry/V,rz/V
local d = ux*hx+uy*hy+uz*hz
local Lx,Ly,Lz = ux-hx*d,uy-hy*d,uz-hz*d
local lm = sqrt(Lx*Lx+Ly*Ly+Lz*Lz)
if lm>.2 then
local c = qk*cl/lm
ax,ay,az = ax+Lx*c,ay+Ly*c,az+Lz*c
end
local dd = qk*cdv+.12*V
ax,ay,az = ax-hx*dd,ay-hy*dd,az-hz*dd
local sd = -.8*P.kL*V*vl
ax,ay,az = ax+lx*sd,ay+ly*sd,az+lz*sd
end
local T = P.tw*G*S.pwr*.01*eng*(1-clamp(vf/P.vm,0,1))
ax,ay,az = ax+fx*T,ay+fy*T,az+fz*T
s.vx,s.vy,s.vz = s.vx+ax*dt,s.vy+ay*dt,s.vz+az*dt
local wash = P.wa*sqrt(eng)
local auth = clamp(sqrt(V*V+wash*wash)/P.vr,.06,1)
local vs = clamp(V/P.vr,0,1.5)
local sf = clamp((aa-P.sa)/.4,0,1)
local RS = S.rates*.01
local pt = ail*P.rl*auth*RS - P.tq*S.torque*.01*eng*eng*(1-clamp(V/12,0,1))
local qt = -ele*P.pt*auth*RS*(1+P.cg*sf) - P.sb*sinA*vs*(1-2*P.cg*sf)
local rt = rud*P.yw*auth*RS - P.sb*.8*sinB*vs
if S.assist==1 and abs(fz)<.85 then
pt = pt-3*atan2(lz,uz)*(1-abs(ail))
qt = qt-3*asin(clamp(fz,-1,1))*(1-abs(ele))
end
if s.gnd then pt = 0 end
local k = min(1,dt/P.ta)
s.p = s.p+(pt-s.p)*k
s.q = s.q+(qt-s.q)*k
s.r = s.r+(rt-s.r)*k
local mx,my,mz
mx,my,mz = -lx,-ly,-lz
ux,uy,uz,mx,my,mz = rot2(ux,uy,uz,mx,my,mz,s.p*dt)
lx,ly,lz = -mx,-my,-mz
fx,fy,fz,ux,uy,uz = rot2(fx,fy,fz,ux,uy,uz,s.q*dt)
mx,my,mz = -lx,-ly,-lz
fx,fy,fz,mx,my,mz = rot2(fx,fy,fz,mx,my,mz,s.r*dt)
lx,ly,lz = -mx,-my,-mz
s.x,s.y,s.z = s.x+s.vx*dt,s.y+s.vy*dt,s.z+s.vz*dt
local gnd = false
if s.z<=ZG then
local spd = sqrt(s.vx*s.vx+s.vy*s.vy+s.vz*s.vz)
if not s.gnd and S.crash==1 and not s.crashed then
if s.vz<-P.cv then doCrash("HARD LANDING")
elseif fz<-.45 and spd>3 then doCrash("NOSE DOWN")
elseif abs(lz)>.55 and spd>3 then doCrash("WING STRIKE")
elseif uz<.2 and spd>2.5 then doCrash("INVERTED")
elseif s.vz<-1.5 then pend("touch") end
end
gnd = true
s.z = ZG
if s.vz<0 then s.vz = 0 end
local vlat = s.vx*lx+s.vy*ly
local kk = min(1,dt*8)
s.vx,s.vy = s.vx-lx*vlat*kk, s.vy-ly*vlat*kk
local fr = 1-min(1,dt*(.3+(thr<.05 and .7 or 0)))
s.vx,s.vy = s.vx*fr,s.vy*fr
if abs(ele)<.2 then
local hx,hy = fx,fy
local hm = sqrt(hx*hx+hy*hy)
if hm<.3 then hx,hy = -ux,-uy hm = sqrt(hx*hx+hy*hy) end
if hm>.001 then
hx,hy = hx/hm,hy/hm
local kb = min(1,dt*2.5)
fx,fy,fz = fx+(hx-fx)*kb,fy+(hy-fy)*kb,fz*(1-kb)
lx,ly,lz = lx+(-hy-lx)*kb,ly+(hx-ly)*kb,lz*(1-kb)
end
end
end
s.gnd = gnd
local n = sqrt(fx*fx+fy*fy+fz*fz) fx,fy,fz = fx/n,fy/n,fz/n
local d = lx*fx+ly*fy+lz*fz
lx,ly,lz = lx-d*fx,ly-d*fy,lz-d*fz
n = sqrt(lx*lx+ly*ly+lz*lz) lx,ly,lz = lx/n,ly/n,lz/n
ux,uy,uz = fy*lz-fz*ly, fz*lx-fx*lz, fx*ly-fy*lx
s.fx,s.fy,s.fz,s.lx,s.ly,s.lz,s.ux,s.uy,s.uz = fx,fy,fz,lx,ly,lz,ux,uy,uz
if S.crash==1 and not s.crashed then
for i=1,#solids do
local o = solids[i]
if s.z<o[#o] then
local dx,dy = s.x-o[2],s.y-o[3]
if o[1]==1 then
if dx*dx+dy*dy<o[4]*o[4] then doCrash("OBSTACLE") break end
elseif abs(dx)<o[4] and abs(dy)<o[5] then doCrash("BUILDING") break end
end
end
end
if S.hoops==1 and not s.crashed then
local h = HOOP[st.nextH]
local hd = h[4]*RAD
local nx,ny = sin(hd),cos(hd)
local dx,dy,dz = s.x-h[1],s.y-h[2],s.z-h[3]
local sd = dx*nx+dy*ny
if s.hsd and s.hsd*sd<0 then
local rad2 = dx*dx+dy*dy+dz*dz-sd*sd
if rad2<(h[5]*1.1)^2 then
st.score = st.score+10
st.nextH = st.nextH+1
pend("hoop")
if st.nextH>#HOOP then st.nextH = 1 st.score = st.score+50 end
sd = nil
end
end
s.hsd = sd
end
if S.gates==1 and not s.crashed then
local g = GATE[st.gn]
local gw = GW[S.gsz+1]
local hd = g[4]*RAD
local nx,ny = sin(hd),cos(hd)
local dx,dy,dz = s.x-g[1],s.y-g[2],s.z-g[3]
local sd = dx*nx+dy*ny
if s.gsd and s.gsd*sd<0 and abs(dx*ny-dy*nx)<gw/2 and abs(dz)<gw*.35 then
st.gp = st.gp+1
st.score = st.score+5
pend("hoop")
if st.gn==1 then
if st.arm then
st.lap = st.lap+1
local lt = s.t-st.lt
if not st.best or lt<st.best then st.best = lt end
st.msg = fmt("LAP %d  %.1fs",st.lap,lt)
st.msgT = 3
st.score = st.score+50
pend("man")
st.arm = false
end
st.lt = s.t
end
st.gn = st.gn+1
if st.gn>#GATE then st.gn = 1 st.arm = true end
sd = nil
end
s.gsd = sd
end
s.ph = s.ph+dt*(8+eng*70)
end
local crx,cry,crz,cux,cuy,cuz,cfx,cfy,cfz = 1,0,0,0,0,1,0,1,0
local cpx,cpy,cpz,cF = 0,0,1,70
local scx,scy = 64,32
local cx0,cy0,cx1,cy1 = 0,0,127,63
local NEAR = .2
local function lookAt(ex,ey,ez,tx,ty,tz)
local dx,dy,dz = tx-ex,ty-ey,tz-ez
local d = sqrt(dx*dx+dy*dy+dz*dz)
if d<.01 then d = .01 end
dx,dy,dz = dx/d,dy/d,dz/d
local rx,ry = dy,-dx
local rl = sqrt(rx*rx+ry*ry)
if rl<.001 then rx,ry = 1,0 else rx,ry = rx/rl,ry/rl end
cpx,cpy,cpz = ex,ey,ez
crx,cry,crz = rx,ry,0
cfx,cfy,cfz = dx,dy,dz
cux,cuy,cuz = ry*dz, -rx*dz, rx*dy-ry*dx
end
local function clipDraw(x1,y1,x2,y2,pat)
local dx,dy = x2-x1,y2-y1
local t0,t1 = 0,1
if dx==0 then if x1<cx0 or x1>cx1 then return end
else
local a,b = (cx0-x1)/dx,(cx1-x1)/dx
if a>b then a,b = b,a end
if a>t0 then t0 = a end
if b<t1 then t1 = b end
if t0>t1 then return end
end
if dy==0 then if y1<cy0 or y1>cy1 then return end
else
local a,b = (cy0-y1)/dy,(cy1-y1)/dy
if a>b then a,b = b,a end
if a>t0 then t0 = a end
if b<t1 then t1 = b end
if t0>t1 then return end
end
lcd.drawLine(floor(x1+dx*t0+.5),floor(y1+dy*t0+.5),floor(x1+dx*t1+.5),floor(y1+dy*t1+.5),pat or SOLID,FORCE)
end
local function line3(ax,ay,az,bx,by,bz,pat)
local dx,dy,dz = ax-cpx,ay-cpy,az-cpz
local x1 = dx*crx+dy*cry+dz*crz
local y1 = dx*cux+dy*cuy+dz*cuz
local z1 = dx*cfx+dy*cfy+dz*cfz
dx,dy,dz = bx-cpx,by-cpy,bz-cpz
local x2 = dx*crx+dy*cry+dz*crz
local y2 = dx*cux+dy*cuy+dz*cuz
local z2 = dx*cfx+dy*cfy+dz*cfz
if z1<NEAR and z2<NEAR then return end
if z1<NEAR then
local t = (NEAR-z1)/(z2-z1)
x1,y1,z1 = x1+(x2-x1)*t,y1+(y2-y1)*t,NEAR
elseif z2<NEAR then
local t = (NEAR-z2)/(z1-z2)
x2,y2,z2 = x2+(x1-x2)*t,y2+(y1-y2)*t,NEAR
end
clipDraw(scx+x1/z1*cF,scy-y1/z1*cF,scx+x2/z2*cF,scy-y2/z2*cF,pat)
end
local function camZ(x,y,z)
return (x-cpx)*cfx+(y-cpy)*cfy+(z-cpz)*cfz
end
local wxs,wys,wzs = {},{},{}
local function drawModel(px,py,pz,fx,fy,fz,lx,ly,lz,ux,uy,uz,eng,ph)
local M = mesh
local vx,vy,vz = M.vx,M.vy,M.vz
for i=1,M.n do
local a,b,c = vx[i],vy[i],vz[i]
wxs[i] = px+fx*a+lx*b+ux*c
wys[i] = py+fy*a+ly*b+uy*c
wzs[i] = pz+fz*a+lz*b+uz*c
end
local ea,eb = M.ea,M.eb
for i=1,#ea do
local a,b = ea[i],eb[i]
line3(wxs[a],wys[a],wzs[a],wxs[b],wys[b],wzs[b])
end
local nx,r = M.nx,M.pr
local c,s = cos(ph)*r,sin(ph)*r
local function pl(yy,zz)
return px+fx*nx+lx*yy+ux*zz, py+fy*nx+ly*yy+uy*zz, pz+fz*nx+lz*yy+uz*zz
end
local ax,ay,az = pl(c,s)
local bx,by,bz = pl(-c,-s)
line3(ax,ay,az,bx,by,bz)
if eng>.45 then
ax,ay,az = pl(-s,c) bx,by,bz = pl(s,-c)
line3(ax,ay,az,bx,by,bz)
end
end
local function drawTree(x,y,h)
local d = camZ(x,y,h*.5)
if d<-2 or d>160 then return end
local r,b = h*.28,h*.3
line3(x,y,0,x,y,h*.35)
line3(x-r,y,b,x,y,h) line3(x+r,y,b,x,y,h)
line3(x,y-r,b,x,y,h) line3(x,y+r,b,x,y,h)
if S.detail>=1 then
line3(x-r,y,b,x,y-r,b) line3(x,y-r,b,x+r,y,b)
line3(x+r,y,b,x,y+r,b) line3(x,y+r,b,x-r,y,b)
end
end
local function drawBox(x,y,hw,hd,h)
if camZ(x,y,h/2)<-12 then return end
local x0,x1,y0,y1 = x-hw,x+hw,y-hd,y+hd
line3(x0,y0,0,x1,y0,0) line3(x1,y0,0,x1,y1,0) line3(x1,y1,0,x0,y1,0) line3(x0,y1,0,x0,y0,0)
line3(x0,y0,h,x1,y0,h) line3(x1,y0,h,x1,y1,h) line3(x1,y1,h,x0,y1,h) line3(x0,y1,h,x0,y0,h)
line3(x0,y0,0,x0,y0,h) line3(x1,y0,0,x1,y0,h) line3(x1,y1,0,x1,y1,h) line3(x0,y1,0,x0,y1,h)
line3(x-hw*.5,y0,0,x-hw*.5,y0,h*.6) line3(x+hw*.5,y0,0,x+hw*.5,y0,h*.6)
line3(x-hw*.5,y0,h*.6,x+hw*.5,y0,h*.6)
end
local function drawRing(cx,cy,cz,nx,ny,r,seg)
local sx,sy = ny,-nx
local px,py,pz = cx+sx*r,cy+sy*r,cz
for i=1,seg do
local a = i*2*PI/seg
local qx,qy,qz = cx+sx*r*cos(a),cy+sy*r*cos(a),cz+r*sin(a)
line3(px,py,pz,qx,qy,qz)
px,py,pz = qx,qy,qz
end
end
local function drawScene()
local s = st
local R = 3000
local ox,oy = cpx,cpy
for i=0,11 do
local a,b = i*PI/6,(i+1)*PI/6
line3(ox+R*cos(a),oy+R*sin(a),0,ox+R*cos(b),oy+R*sin(b),0)
end
if S.grid==1 then
local gs = ({40,25,15})[S.detail+1]
local gx,gy = floor(s.x/gs)*gs,floor(s.y/gs)*gs
local E = gs*5
for i=-5,5 do
line3(gx+i*gs,gy-E,0,gx+i*gs,gy+E,0,DOTTED)
line3(gx-E,gy+i*gs,0,gx+E,gy+i*gs,0,DOTTED)
end
end
if S.rway==1 then
line3(-3,-50,0,-3,50,0) line3(3,-50,0,3,50,0)
line3(-3,-50,0,3,-50,0) line3(-3,50,0,3,50,0)
line3(0,-50,0,0,50,0,DOTTED)
line3(-3,-44,0,3,-44,0) line3(-3,44,0,3,44,0)
end
if S.wTherm==1 and S.wOn==1 then
drawRing(THERM[1],THERM[2],0.1,0,1,THERM[3],10)
line3(THERM[1],THERM[2],0,THERM[1],THERM[2],25,DOTTED)
end
if S.trees==1 then
for i=1,({6,10,16})[S.detail+1] do
local t = TREES[i] drawTree(t[1],t[2],6+(i*7)%5)
end
end
if S.bldg==1 then
for i=1,#BLDG do local b = BLDG[i] drawBox(b[1],b[2],b[3]/2,b[4]/2,b[5]) end
end
if S.pyl==1 then
for i=1,#PYL do
local p = PYL[i]
if camZ(p[1],p[2],4)>-5 then
line3(p[1],p[2],0,p[1],p[2],8)
line3(p[1],p[2],8,p[1]+1,p[2],7.3) line3(p[1]+1,p[2],7.3,p[1],p[2],6.6)
line3(p[1],p[2],6.6,p[1],p[2],8)
end
end
end
if S.hoops==1 then
for i=1,#HOOP do
local h = HOOP[i]
local a = h[4]*RAD
if i==st.nextH then
drawRing(h[1],h[2],h[3],sin(a),cos(a),h[5],12)
drawRing(h[1],h[2],h[3],sin(a),cos(a),h[5]*.85,12)
elseif camZ(h[1],h[2],h[3])>-2 then
drawRing(h[1],h[2],h[3],sin(a),cos(a),h[5],6)
end
end
end
if S.gates==1 then
local hw = GW[S.gsz+1]/2
local hh = hw*.7
for i=1,#GATE do
local g = GATE[i]
if camZ(g[1],g[2],g[3])>-2 then
local a = g[4]*RAD
local sx,sy = cos(a)*hw,-sin(a)*hw
local x0,y0,x1,y1 = g[1]-sx,g[2]-sy,g[1]+sx,g[2]+sy
local zl,zh = g[3]-hh,g[3]+hh
line3(x0,y0,zh,x1,y1,zh) line3(x0,y0,zl,x1,y1,zl)
line3(x0,y0,zl,x0,y0,zh) line3(x1,y1,zl,x1,y1,zh)
line3(x0,y0,0,x0,y0,zl) line3(x1,y1,0,x1,y1,zl)
if i==st.gn then
line3(x0,y0,zl,x1,y1,zh) line3(x0,y0,zh,x1,y1,zl)
end
end
end
end
if S.sock==1 then
local x,y = SOCK[1],SOCK[2]
line3(x,y,0,x,y,3.5)
local wl = sqrt(s.wx*s.wx+s.wy*s.wy)
if S.wOn==0 or wl<.2 then wl = 0 end
local dx,dy = 0,1
if wl>0 then dx,dy = s.wx/wl,s.wy/wl end
local drop = max(0,1-wl/6)*1.1
local tx,ty,tz = x+dx*1.4*(1-drop*.5),y+dy*1.4*(1-drop*.5),3.5-drop
local ex,ey = -dy*.25,dx*.25
line3(x,y,3.5,tx,ty,tz)
line3(x+ex,y+ey,3.5,tx,ty,tz) line3(x-ex,y-ey,3.5,tx,ty,tz)
line3(x+ex,y+ey,3.5,x-ex,y-ey,3.5)
end
if S.cam~=2 then
local sz = P.len*.35
line3(s.x-sz,s.y,0,s.x+sz,s.y,0) line3(s.x,s.y-sz,0,s.x,s.y+sz,0)
if s.z>1.2 then line3(s.x,s.y,s.z,s.x,s.y,0,DOTTED) end
if s.crashed then
local k = s.ct*4
for i=1,#s.deb do
local d = s.deb[i]
line3(s.x,s.y,s.z,s.x+d[1]*k,s.y+d[2]*k,max(0,s.z+d[3]*k-k*k*.8))
end
else
drawModel(s.x,s.y,s.z,s.fx,s.fy,s.fz,s.lx,s.ly,s.lz,s.ux,s.uy,s.uz,s.eng,s.ph)
end
end
end
local chx,chy = 0,1
local function setupCamera(dt)
local s = st
if S.cam==0 then
lookAt(PX,PY,PZ,s.x,s.y,s.z)
local d = sqrt((s.x-PX)^2+(s.y-PY)^2+(s.z-PZ)^2)
local Ft = clamp(14*d*S.zoom*.1,70,520)
cF = cF+(Ft-cF)*min(1,dt*6)
elseif S.cam==1 then
local hx,hy = s.vx,s.vy
if hx*hx+hy*hy<4 then hx,hy = s.fx,s.fy end
local hm = sqrt(hx*hx+hy*hy)
if hm<.2 then hx,hy = chx,chy hm = 1 end
hx,hy = hx/hm,hy/hm
local k = min(1,dt*3)
chx,chy = chx+(hx-chx)*k,chy+(hy-chy)*k
local cm = sqrt(chx*chx+chy*chy) if cm<.01 then cm = 1 end
chx,chy = chx/cm,chy/cm
local dist = (4+P.len*1.5)*S.zoom*.1
lookAt(s.x-chx*dist,s.y-chy*dist,max(.5,s.z+dist*.3),s.x,s.y,s.z)
cF = 75
else
cpx,cpy,cpz = s.x+s.fx*.4+s.ux*.12,s.y+s.fy*.4+s.uy*.12,s.z+s.fz*.4+s.uz*.12
crx,cry,crz = -s.lx,-s.ly,-s.lz
cux,cuy,cuz = s.ux,s.uy,s.uz
cfx,cfy,cfz = s.fx,s.fy,s.fz
cF = 60
end
end
local function hud()
local s = st
lcd.drawText(0,0,fmt("%dkm/h %dm",floor(s.V*3.6+.5),floor(s.z-ZG+.5)),SM)
if S.hoops==1 then lcd.drawText(floor(W/2)-6,0,fmt("H%d",st.nextH),SM) end
lcd.drawText(0,57,fmt("%d",st.score),SM)
if S.gates==1 then
lcd.drawText(0,8,fmt("G%d/%d L%d P%d",st.gn,#GATE,st.lap,st.gp),SM)
if st.lt then lcd.drawText(W-52,8,fmt("%.1fs",s.t-st.lt),SM) end
if st.best then lcd.drawText(0,16,fmt("BEST %.1fs",st.best),SM) end
end
if st.msgT>0 then lcd.drawText(floor(W/2)-#st.msg*3,18,st.msg,SM+INVERS) end
lcd.drawFilledRectangle(W-4,63-floor(inp.thr*20),3,floor(inp.thr*20)+1)
lcd.drawRectangle(W-5,43,5,21)
if S.pspd~=100 then lcd.drawText(floor(W/2)-12,57,"SIM "..S.pspd.."%",SM) end
if s.manT>0 then
lcd.drawText(floor(W/2)-#s.manName*3,48,s.manName,SM+INVERS)
end
if not s.gnd and abs(s.al)>P.sa and s.V>4 and not s.crashed then
lcd.drawText(floor(W/2)-12,10,"STALL",SM+BLINK)
end
if S.wOn==1 then
local wl = sqrt(s.wx*s.wx+s.wy*s.wy)
if wl>.3 then
local ex = (s.wx*crx+s.wy*cry)/wl
local ey = (s.wx*cfx+s.wy*cfy)/wl
local ax,ay = W-12,13
local bx,by = ax+ex*7,ay-ey*7
lcd.drawLine(floor(ax),floor(ay),floor(bx),floor(by),SOLID,FORCE)
local ang = atan2(by-ay,bx-ax)
lcd.drawLine(floor(bx),floor(by),floor(bx-4*cos(ang-.5)),floor(by-4*sin(ang-.5)),SOLID,FORCE)
lcd.drawLine(floor(bx),floor(by),floor(bx-4*cos(ang+.5)),floor(by-4*sin(ang+.5)),SOLID,FORCE)
lcd.drawText(W-44,0,fmt("%dkm/h",floor(wl*3.6+.5)),SM)
end
end
if s.crashed then
lcd.drawText(floor(W/2)-28,22,"CRASH!",MIDSIZE)
lcd.drawText(floor(W/2)-#(s.why or "")*3,40,s.why or "",SM)
end
end
local function soundTick(now)
if now-lastSnd<12 then return end
lastSnd = now
local s = st
local p = pending
pending = nil
if p and S.sFx==1 or (p=="man" and S.sCall==1) then
if p=="crash" then playTone(500,500*TU,0,PN,-12)
elseif p=="hoop" then playTone(1400,80*TU,0,PN,8) playTone(1900,120*TU,0,PN)
elseif p=="man" then
if S.sCall==1 then playTone(900,70*TU,10,PN) playTone(1300,70*TU,10,PN) playTone(1700,130*TU,0,PN) end
elseif p=="touch" then playTone(250,70*TU,0,PN) end
return
end
if s.crashed then return end
if S.sStall==1 and not s.gnd and abs(s.al)>P.sa and s.V>4 then
playTone(1900,70*TU,30,PN) return
end
sndTog = 1-sndTog
if S.sVario==1 and sndTog==1 and not s.gnd then
playTone(clamp(700+s.vz*80,250,2200),90*TU,0,PB) return
end
if S.sWind==1 and S.wOn==1 and sndTog==0 and (s.wx*s.wx+s.wy*s.wy)>36 then
playTone(110+rnd(0,40),100*TU,0,PB) return
end
if S.sEng==1 and s.eng>.04 then
playTone(floor(110+s.eng*330+s.V*2),110*TU,0,PB)
end
end
local lastSH=false
local function readInputs()
local e=S.expo*.01
local function ex(v) v=clamp(v/1024,-1,1) return (1-e)*v+e*v*v*v end
inp.ail=ex(getValue("ail") or 0)
inp.ele=ex(getValue("ele") or 0)
if S.eRev==1 then inp.ele=-inp.ele end
inp.rud=ex(getValue("rud") or 0)
inp.thr=clamp(((getValue("thr") or -1024)+1024)/2048,0,1)
if inp.thr<.03 then inp.thr=0 end
end
local function run(act,dt,now)
W=X.W() scx=floor(W/2) cx1=W-1
if act=="menu" or act=="exit" then X.save() X.mode="menu" return end
if act=="page" then S.cam=(S.cam+1)%3 end
if act=="next" then S.zoom=min(30,S.zoom+1) elseif act=="prev" then S.zoom=max(5,S.zoom-1) end
local sh=(getValue("sh") or 0)>512
if act=="enter" or (sh and not lastSH) then resetPlane() end
lastSH=sh
readInputs()
local s=st
if s.crashed then
s.ct=s.ct+dt
if S.aReset==1 and s.ct>3 then resetPlane() end
else
local pd=dt*S.pspd*.01
local n=min(8,floor(pd/.03)+1)
local h=pd/n
for i=1,n do stepPhys(h) end
if S.mdet==1 then detect(pd) else s.manT = 0 end
end
if s.manT>0 then s.manT=s.manT-dt end
if st.msgT>0 then st.msgT=st.msgT-dt end
lcd.clear()
setupCamera(dt)
drawScene()
hud()
soundTick(now)
end
st.score=st.score or 0
st.nextH=st.nextH or 1
st.gp=st.gp or 0
st.lap=st.lap or 0
st.gn=st.gn or 1
st.msgT=st.msgT or 0
st.msg=st.msg or ""
if X.rst or not st.fx then X.rst=false resetPlane() else loadPlane(S.plane) buildSolids() end
return {run=run}
